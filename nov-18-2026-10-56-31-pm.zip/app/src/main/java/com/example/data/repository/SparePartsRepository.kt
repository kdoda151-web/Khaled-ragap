package com.example.data.repository

import com.example.data.local.SpareMisrDatabase
import com.example.data.local.SparePartsCatalogSeed
import com.example.data.local.SparePartsDao
import com.example.data.model.CartItemEntity
import com.example.data.model.CartItemWithPart
import com.example.data.model.EgyptGovernorate
import com.example.data.model.EgyptianCarBrand
import com.example.data.model.EgyptianCarModel
import com.example.data.model.FavoritePartEntity
import com.example.data.model.GarageVehicleEntity
import com.example.data.model.MaintenanceMilestone
import com.example.data.model.OrderEntity
import com.example.data.model.SparePartEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlin.random.Random

class SparePartsRepository(private val dao: SparePartsDao) {

    val brands: List<EgyptianCarBrand> = SparePartsCatalogSeed.brands
    val allCarModels: List<EgyptianCarModel> = SparePartsCatalogSeed.carModels
    val governorates: List<EgyptGovernorate> = SparePartsCatalogSeed.governorates
    val maintenanceMilestones: List<MaintenanceMilestone> = SparePartsCatalogSeed.maintenanceMilestones

    val allParts: Flow<List<SparePartEntity>> = dao.observeAllParts()
    val garageVehicles: Flow<List<GarageVehicleEntity>> = dao.observeGarageVehicles()
    val activeVehicle: Flow<GarageVehicleEntity?> = dao.observeActiveVehicle()
    val favoriteIds: Flow<List<String>> = dao.observeFavoriteIds()
    val orders: Flow<List<OrderEntity>> = dao.observeOrders()

    val cartItemsWithParts: Flow<List<CartItemWithPart>> = combine(
        dao.observeCartItems(),
        dao.observeAllParts()
    ) { cartItems, parts ->
        val partsMap = parts.associateBy { it.id }
        cartItems.mapNotNull { item ->
            partsMap[item.partId]?.let { part ->
                CartItemWithPart(cartItem = item, part = part)
            }
        }
    }

    suspend fun initializeDatabase() {
        SpareMisrDatabase.ensureSeeded(dao)
    }

    fun observePartById(partId: String): Flow<SparePartEntity?> = dao.observePartById(partId)

    fun modelsForBrand(brandId: String): List<EgyptianCarModel> =
        allCarModels.filter { it.brandId == brandId }

    fun findCarModel(carModelId: String): EgyptianCarModel? =
        allCarModels.find { it.id == carModelId }

    fun compatibleModelsForPart(part: SparePartEntity): List<EgyptianCarModel> {
        if (part.compatibleCarIdsCsv.contains("ALL_EGYPT")) {
            return allCarModels.filter { it.isTopSellerInEgypt }
        }
        val ids = part.compatibleCarIdsCsv.split(",").map { it.trim() }.toSet()
        return allCarModels.filter { it.id in ids }
    }

    suspend fun addAndActivateVehicle(
        model: EgyptianCarModel,
        year: Int,
        engineSpec: String,
        nickname: String
    ) {
        val cleanNickname = nickname.trim().ifEmpty { model.displayTitleAr }
        dao.addAndActivateVehicle(
            GarageVehicleEntity(
                carModelId = model.id,
                brandNameAr = model.brandNameAr,
                modelNameAr = model.nameAr,
                chassisCode = model.chassisCode,
                year = year,
                engineSpec = engineSpec,
                nickname = cleanNickname,
                isActive = true
            )
        )
    }

    suspend fun activateVehicle(vehicleId: Int) {
        dao.setActiveVehicle(vehicleId)
    }

    suspend fun deleteVehicle(vehicleId: Int) {
        dao.deleteVehicle(vehicleId)
    }

    suspend fun addToCart(partId: String, quantityDelta: Int = 1) {
        val existing = dao.getCartItem(partId)
        val newQty = (existing?.quantity ?: 0) + quantityDelta
        if (newQty <= 0) {
            dao.deleteCartItem(partId)
        } else {
            dao.upsertCartItem(
                CartItemEntity(
                    partId = partId,
                    quantity = newQty.coerceAtMost(20)
                )
            )
        }
    }

    suspend fun updateCartQuantity(partId: String, quantity: Int) {
        if (quantity <= 0) {
            dao.deleteCartItem(partId)
        } else {
            dao.upsertCartItem(CartItemEntity(partId = partId, quantity = quantity.coerceAtMost(20)))
        }
    }

    suspend fun removeFromCart(partId: String) {
        dao.deleteCartItem(partId)
    }

    suspend fun toggleFavorite(partId: String) {
        if (dao.isFavorite(partId)) {
            dao.removeFavorite(partId)
        } else {
            dao.addFavorite(FavoritePartEntity(partId = partId))
        }
    }

    suspend fun placeOrder(
        customerName: String,
        phone: String,
        governorate: EgyptGovernorate,
        address: String,
        paymentMethodAr: String,
        cartItems: List<CartItemWithPart>
    ): OrderEntity {
        val subtotal = cartItems.sumOf { it.part.priceEgp * it.cartItem.quantity }
        val shipping = governorate.shippingFeeEgp
        val total = subtotal + shipping
        val summary = cartItems.joinToString(" • ") {
            "${it.part.nameAr} (×${it.cartItem.quantity})"
        }
        val orderNum = "EG-${Random.nextInt(100000, 999999)}"
        val order = OrderEntity(
            orderNumber = orderNum,
            customerName = customerName.trim(),
            phone = phone.trim(),
            governorateAr = governorate.nameAr,
            address = address.trim(),
            paymentMethodAr = paymentMethodAr,
            totalEgp = total,
            shippingEgp = shipping,
            itemsSummaryAr = summary,
            itemCount = cartItems.sumOf { it.cartItem.quantity },
            statusAr = "تم استلام الطلب وجاري التجهيز"
        )
        dao.insertOrder(order)
        dao.clearCart()
        return order
    }
}
