package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.CartItemEntity
import com.example.data.model.FavoritePartEntity
import com.example.data.model.GarageVehicleEntity
import com.example.data.model.OrderEntity
import com.example.data.model.SparePartEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SparePartsDao {

    // --- Spare Parts Catalog ---
    @Query("SELECT * FROM spare_parts ORDER BY isPopularInEgypt DESC, rating DESC")
    fun observeAllParts(): Flow<List<SparePartEntity>>

    @Query("SELECT * FROM spare_parts WHERE id = :partId LIMIT 1")
    fun observePartById(partId: String): Flow<SparePartEntity?>

    @Query("SELECT COUNT(*) FROM spare_parts")
    suspend fun getPartsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParts(parts: List<SparePartEntity>)

    // --- Garage Vehicles ---
    @Query("SELECT * FROM garage_vehicles ORDER BY isActive DESC, addedAt DESC")
    fun observeGarageVehicles(): Flow<List<GarageVehicleEntity>>

    @Query("SELECT * FROM garage_vehicles WHERE isActive = 1 LIMIT 1")
    fun observeActiveVehicle(): Flow<GarageVehicleEntity?>

    @Query("UPDATE garage_vehicles SET isActive = 0")
    suspend fun clearAllActiveVehicles()

    @Query("UPDATE garage_vehicles SET isActive = 1 WHERE id = :vehicleId")
    suspend fun markVehicleActive(vehicleId: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: GarageVehicleEntity): Long

    @Query("DELETE FROM garage_vehicles WHERE id = :vehicleId")
    suspend fun deleteVehicle(vehicleId: Int)

    @Query("SELECT COUNT(*) FROM garage_vehicles")
    suspend fun getVehiclesCount(): Int

    @Transaction
    suspend fun addAndActivateVehicle(vehicle: GarageVehicleEntity) {
        clearAllActiveVehicles()
        insertVehicle(vehicle.copy(isActive = true))
    }

    @Transaction
    suspend fun setActiveVehicle(vehicleId: Int) {
        clearAllActiveVehicles()
        markVehicleActive(vehicleId)
    }

    // --- Cart ---
    @Query("SELECT * FROM cart_items ORDER BY addedAt DESC")
    fun observeCartItems(): Flow<List<CartItemEntity>>

    @Query("SELECT * FROM cart_items WHERE partId = :partId LIMIT 1")
    suspend fun getCartItem(partId: String): CartItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCartItem(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE partId = :partId")
    suspend fun deleteCartItem(partId: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    // --- Favorites ---
    @Query("SELECT partId FROM favorite_parts")
    fun observeFavoriteIds(): Flow<List<String>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_parts WHERE partId = :partId)")
    suspend fun isFavorite(partId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoritePartEntity)

    @Query("DELETE FROM favorite_parts WHERE partId = :partId")
    suspend fun removeFavorite(partId: String)

    // --- Orders ---
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun observeOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)
}
