package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.CartItemEntity
import com.example.data.model.FavoritePartEntity
import com.example.data.model.GarageVehicleEntity
import com.example.data.model.OrderEntity
import com.example.data.model.SparePartEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SparePartEntity::class,
        GarageVehicleEntity::class,
        CartItemEntity::class,
        FavoritePartEntity::class,
        OrderEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SpareMisrDatabase : RoomDatabase() {

    abstract fun sparePartsDao(): SparePartsDao

    companion object {
        @Volatile
        private var INSTANCE: SpareMisrDatabase? = null

        fun getInstance(context: Context): SpareMisrDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SpareMisrDatabase::class.java,
                    "spare_misr_db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    seedInitialData(database.sparePartsDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun ensureSeeded(dao: SparePartsDao) {
            if (dao.getPartsCount() == 0) {
                seedInitialData(dao)
            }
        }

        private suspend fun seedInitialData(dao: SparePartsDao) {
            dao.insertParts(SparePartsCatalogSeed.spareParts)
            if (dao.getVehiclesCount() == 0) {
                // Seed default popular Egyptian car so first-time users immediately see compatibility badges
                dao.addAndActivateVehicle(
                    GarageVehicleEntity(
                        carModelId = "nissan_sunny_n17",
                        brandNameAr = "نيسان",
                        modelNameAr = "صني الشكل الجديد",
                        chassisCode = "N17",
                        year = 2022,
                        engineSpec = "1.5L HR15DE",
                        nickname = "سيارتي الرئيسية",
                        isActive = true
                    )
                )
            }
        }
    }
}
