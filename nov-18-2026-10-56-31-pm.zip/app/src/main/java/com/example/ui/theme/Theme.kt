package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = SignalCopper,
    onPrimary = Color.White,
    primaryContainer = CopperContainer,
    onPrimaryContainer = OnCopperContainer,
    secondary = AsphaltSlate,
    onSecondary = Color.White,
    secondaryContainer = SlateContainer,
    onSecondaryContainer = OnSlateContainer,
    tertiary = NileTeal,
    onTertiary = Color.White,
    tertiaryContainer = TealContainer,
    onTertiaryContainer = OnTealContainer,
    background = WorkshopBackground,
    onBackground = TextPrimaryLight,
    surface = PureSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceMuted,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLowest = PureSurface,
    surfaceContainerLow = Color(0xFFF9FAFB),
    surfaceContainer = SurfaceMuted,
    surfaceContainerHigh = Color(0xFFE5E9F0),
    outline = OutlineStone,
    error = StatusError,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = SignalAmberBright,
    onPrimary = Color(0xFF280D00),
    primaryContainer = CopperContainerDark,
    onPrimaryContainer = OnCopperContainerDark,
    secondary = SteelSlateBright,
    onSecondary = Color(0xFF0F172A),
    secondaryContainer = SlateContainerDark,
    onSecondaryContainer = OnSlateContainerDark,
    tertiary = PrecisionTealBright,
    onTertiary = Color(0xFF002823),
    tertiaryContainer = TealContainerDark,
    onTertiaryContainer = OnTealContainerDark,
    background = CarbonBackground,
    onBackground = TextPrimaryDark,
    surface = GraphiteSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = GraphiteElevated,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLowest = Color(0xFF0A0E14),
    surfaceContainerLow = GraphiteSurface,
    surfaceContainer = GraphiteElevated,
    surfaceContainerHigh = Color(0xFF273446),
    outline = OutlineCarbon,
    error = StatusErrorDark,
    onError = Color(0xFF450A0A)
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun SpareMisrTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
