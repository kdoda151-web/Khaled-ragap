package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.EgyptGovernorate
import com.example.data.model.OrderEntity
import com.example.data.model.PartCategory
import com.example.data.model.SparePartEntity
import com.example.ui.components.CategoryIconBadge
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SparePartCard
import com.example.ui.components.formatEgp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.SpareMisrUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CartScreen(
    uiState: SpareMisrUiState,
    onUpdateQuantity: (String, Int) -> Unit,
    onRemoveFromCart: (String) -> Unit,
    onSelectGovernorate: (EgyptGovernorate) -> Unit,
    onPlaceOrder: (name: String, phone: String, address: String, paymentMethod: String, onSuccess: (OrderEntity) -> Unit) -> Unit,
    onBrowseCatalog: () -> Unit,
    onPartClick: (SparePartEntity) -> Unit,
    onAddToCart: (SparePartEntity) -> Unit,
    onToggleFavorite: (SparePartEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Cart, 1 = Favorites, 2 = Orders
    var customerName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("الدفع نقداً عند الاستلام") }
    var formError by remember { mutableStateOf<String?>(null) }
    var confirmedOrder by remember { mutableStateOf<OrderEntity?>(null) }

    val paymentOptions = listOf(
        "الدفع نقداً عند الاستلام",
        "فودافون كاش / انستاباي",
        "بطاقة بنكية عند الاستلام"
    )

    confirmedOrder?.let { order ->
        AlertDialog(
            onDismissRequest = { confirmedOrder = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(42.dp)
                )
            },
            title = {
                Text(
                    text = "تم تأكيد طلبك بنجاح",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("رقم الطلب: ${order.orderNumber}")
                    Text("الإجمالي: ${formatEgp(order.totalEgp)}")
                    Text("المحافظة: ${order.governorateAr}")
                    Text("سيتم التواصل معك على ${order.phone} لتأكيد موعد المندوب.")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmedOrder = null
                        selectedTab = 2
                    }
                ) {
                    Text("متابعة طلباتي")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmedOrder = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("cart_screen")
    ) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            val tabs = listOf(
                "السلة (${uiState.cartTotalCount})",
                "المفضلة (${uiState.favoriteParts.size})",
                "طلباتي (${uiState.orders.size})"
            )
            tabs.forEachIndexed { index, title ->
                SegmentedButton(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = tabs.size),
                    modifier = Modifier.testTag("cart_tab_$index")
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> {
                if (uiState.cartItems.isEmpty()) {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Default.ShoppingCart,
                                title = "سلة المشتريات فارغة",
                                subtitle = "تصفح قطع غيار سيارتك في السوق المصري وأضف ما تحتاجه للصيانة أو الإصلاح.",
                                actionLabel = "تصفح الكتالوج",
                                onActionClick = onBrowseCatalog
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.cartItems, key = { it.part.id }) { item ->
                            val category = PartCategory.fromId(item.part.categoryId) ?: PartCategory.ENGINE
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CategoryIconBadge(category = category)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.part.nameAr,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${item.part.brandMaker} • ${formatEgp(item.part.priceEgp)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        FilledTonalIconButton(
                                            onClick = {
                                                onUpdateQuantity(item.part.id, item.cartItem.quantity - 1)
                                            },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(Icons.Default.Remove, contentDescription = "إنقاص")
                                        }
                                        Text(
                                            text = item.cartItem.quantity.toString(),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                        FilledTonalIconButton(
                                            onClick = {
                                                onUpdateQuantity(item.part.id, item.cartItem.quantity + 1)
                                            },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "زيادة")
                                        }
                                        IconButton(
                                            onClick = { onRemoveFromCart(item.part.id) },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Governorate Shipping Selection
                        item {
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.LocalShipping,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "اختر محافظة التوصيل في مصر",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        uiState.governorates.forEach { gov ->
                                            FilterChip(
                                                selected = uiState.selectedGovernorate.id == gov.id,
                                                onClick = { onSelectGovernorate(gov) },
                                                label = {
                                                    Text("${gov.nameAr} (${gov.shippingFeeEgp} ج.م)")
                                                }
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = uiState.selectedGovernorate.deliveryEtaAr,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }

                        // Summary + Checkout Form
                        item {
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "ملخص الطلب وبيانات الاستلام",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("إجمالي القطع (${uiState.cartTotalCount})")
                                        Text(
                                            text = formatEgp(uiState.cartSubtotalEgp),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("شحن (${uiState.selectedGovernorate.nameAr})")
                                        Text(
                                            text = formatEgp(uiState.selectedGovernorate.shippingFeeEgp),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "الإجمالي النهائي",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = formatEgp(uiState.cartGrandTotalEgp),
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    OutlinedTextField(
                                        value = customerName,
                                        onValueChange = {
                                            customerName = it
                                            formError = null
                                        },
                                        label = { Text("الاسم الكامل") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("checkout_name_input")
                                    )
                                    OutlinedTextField(
                                        value = phone,
                                        onValueChange = {
                                            phone = it
                                            formError = null
                                        },
                                        label = { Text("رقم الموبايل (مثال: 01012345678)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("checkout_phone_input")
                                    )
                                    OutlinedTextField(
                                        value = address,
                                        onValueChange = {
                                            address = it
                                            formError = null
                                        },
                                        label = { Text("العنوان بالتفصيل (المنطقة، الشارع، أقرب علامة)") },
                                        minLines = 2,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("checkout_address_input")
                                    )

                                    Text(
                                        text = "طريقة الدفع:",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        paymentOptions.forEach { method ->
                                            FilterChip(
                                                selected = paymentMethod == method,
                                                onClick = { paymentMethod = method },
                                                label = { Text(method) }
                                            )
                                        }
                                    }

                                    if (formError != null) {
                                        Text(
                                            text = formError!!,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            val cleanPhone = phone.trim()
                                            when {
                                                customerName.trim().length < 3 ->
                                                    formError = "يرجى إدخال الاسم الكامل"
                                                !cleanPhone.matches(Regex("^01[0125][0-9]{8}$")) ->
                                                    formError = "يرجى إدخال رقم موبايل مصري صحيح (11 رقم يبدأ بـ 01)"
                                                address.trim().length < 6 ->
                                                    formError = "يرجى إدخال عنوان التوصيل بالتفصيل"
                                                else -> {
                                                    onPlaceOrder(
                                                        customerName,
                                                        cleanPhone,
                                                        address,
                                                        paymentMethod
                                                    ) { order ->
                                                        customerName = ""
                                                        phone = ""
                                                        address = ""
                                                        confirmedOrder = order
                                                    }
                                                }
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                            .testTag("place_order_btn"),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Text(
                                            text = "تأكيد الطلب • ${formatEgp(uiState.cartGrandTotalEgp)}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        item { Spacer(modifier = Modifier.height(16.dp)) }
                    }
                }
            }

            1 -> {
                if (uiState.favoriteParts.isEmpty()) {
                    LazyColumn(contentPadding = PaddingValues(16.dp)) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Default.FavoriteBorder,
                                title = "لا توجد قطع في المفضلة",
                                subtitle = "اضغط على أيقونة القلب بجانب أي قطعة غيار لحفظها والرجوع لها وقت الصيانة.",
                                actionLabel = "استكشاف القطع",
                                onActionClick = onBrowseCatalog
                            )
                        }
                    }
                } else {
                    val activeCarId = uiState.activeVehicle?.carModelId
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.favoriteParts, key = { it.id }) { part ->
                            SparePartCard(
                                part = part,
                                isCompatibleWithActiveCar = part.isCompatibleWith(activeCarId),
                                isFavorite = true,
                                onCardClick = { onPartClick(part) },
                                onAddToCart = { onAddToCart(part) },
                                onToggleFavorite = { onToggleFavorite(part) }
                            )
                        }
                    }
                }
            }

            else -> {
                if (uiState.orders.isEmpty()) {
                    LazyColumn(contentPadding = PaddingValues(16.dp)) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Default.ReceiptLong,
                                title = "لا توجد طلبات سابقة",
                                subtitle = "بعد تأكيد طلبك الأول ستظهر تفاصيل الطلب ورقم المتابعة هنا.",
                                actionLabel = "تصفح القطع",
                                onActionClick = onBrowseCatalog
                            )
                        }
                    }
                } else {
                    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy • hh:mm a", Locale("ar", "EG")) }
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.orders, key = { it.id }) { order ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = order.orderNumber,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontFamily = JetBrainsMonoFontFamily
                                            ),
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.tertiaryContainer
                                        ) {
                                            Text(
                                                text = order.statusAr,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = dateFormat.format(Date(order.createdAt)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = order.itemsSummaryAr,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${order.governorateAr} • ${order.paymentMethodAr}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = formatEgp(order.totalEgp),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
