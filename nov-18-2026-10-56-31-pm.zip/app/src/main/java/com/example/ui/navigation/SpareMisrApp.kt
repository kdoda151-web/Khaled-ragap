package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.VehicleSelectorBottomSheet
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CatalogScreen
import com.example.ui.screens.GarageScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PartDetailScreen
import com.example.ui.viewmodel.MainViewModel

sealed class AppDestination(
    val route: String,
    val titleAr: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Home : AppDestination("home", "الرئيسية", Icons.Filled.Home, Icons.Outlined.Home)
    data object Catalog : AppDestination("catalog", "الكتالوج", Icons.Filled.Build, Icons.Outlined.Build)
    data object Garage : AppDestination("garage", "جراجي", Icons.Filled.DirectionsCar, Icons.Outlined.DirectionsCar)
    data object Cart : AppDestination("cart", "السلة", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart)

    companion object {
        const val ROUTE_PART_DETAIL = "part_detail/{partId}"
        fun partDetailRoute(partId: String) = "part_detail/$partId"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpareMisrApp(
    viewModel: MainViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val isVehicleSheetVisible by viewModel.isVehicleSheetVisible.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val snackbarHostState = remember { SnackbarHostState() }

    val topLevelDestinations = listOf(
        AppDestination.Home,
        AppDestination.Catalog,
        AppDestination.Garage,
        AppDestination.Cart
    )

    val isTopLevelRoute = topLevelDestinations.any { dest ->
        currentDestination?.hierarchy?.any { it.route == dest.route } == true
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarMessages.collect { msg ->
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(msg)
        }
    }

    fun navigateTopLevel(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    // Enforce RTL layout for authentic Arabic experience regardless of device system locale
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavRail = maxWidth >= 680.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                topBar = {
                    if (isTopLevelRoute) {
                        CenterAlignedTopAppBar(
                            title = {
                                Text(
                                    text = when (currentDestination?.route) {
                                        AppDestination.Catalog.route -> "كتالوج قطع الغيار"
                                        AppDestination.Garage.route -> "جراج سياراتي"
                                        AppDestination.Cart.route -> "السلة والطلبات"
                                        else -> "اسبير مصر"
                                    },
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background
                            )
                        )
                    }
                },
                bottomBar = {
                    if (isTopLevelRoute && !useNavRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            topLevelDestinations.forEach { dest ->
                                val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(dest.route) },
                                    icon = {
                                        if (dest == AppDestination.Cart && uiState.cartTotalCount > 0) {
                                            BadgedBox(
                                                badge = {
                                                    Badge {
                                                        Text(uiState.cartTotalCount.toString())
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                    contentDescription = dest.titleAr
                                                )
                                            }
                                        } else {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.titleAr
                                            )
                                        }
                                    },
                                    label = { Text(dest.titleAr) },
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isTopLevelRoute && useNavRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            topLevelDestinations.forEach { dest ->
                                val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(dest.route) },
                                    icon = {
                                        if (dest == AppDestination.Cart && uiState.cartTotalCount > 0) {
                                            BadgedBox(
                                                badge = {
                                                    Badge { Text(uiState.cartTotalCount.toString()) }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                    contentDescription = dest.titleAr
                                                )
                                            }
                                        } else {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = dest.titleAr
                                            )
                                        }
                                    },
                                    label = { Text(dest.titleAr) }
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = AppDestination.Home.route,
                            modifier = Modifier.widthIn(max = 980.dp)
                        ) {
                            composable(AppDestination.Home.route) {
                                HomeScreen(
                                    uiState = uiState,
                                    onChangeCarClick = { viewModel.openVehicleSheet() },
                                    onOpenCatalogSearch = {
                                        navigateTopLevel(AppDestination.Catalog.route)
                                    },
                                    onSelectCategory = { category ->
                                        viewModel.applyQuickFilterForCategory(category)
                                        navigateTopLevel(AppDestination.Catalog.route)
                                    },
                                    onSelectPopularCar = { car ->
                                        viewModel.quickActivatePopularCar(car)
                                        navigateTopLevel(AppDestination.Catalog.route)
                                    },
                                    onOpenGarageMaintenance = {
                                        navigateTopLevel(AppDestination.Garage.route)
                                    },
                                    onPartClick = { part ->
                                        navController.navigate(AppDestination.partDetailRoute(part.id))
                                    },
                                    onAddToCart = { part -> viewModel.addToCart(part) },
                                    onToggleFavorite = { part -> viewModel.toggleFavorite(part) }
                                )
                            }

                            composable(AppDestination.Catalog.route) {
                                CatalogScreen(
                                    uiState = uiState,
                                    onSearchQueryChange = viewModel::updateSearchQuery,
                                    onSelectCategory = viewModel::selectCategory,
                                    onSelectQuality = viewModel::selectQuality,
                                    onSelectBrand = viewModel::selectBrandFilter,
                                    onToggleCompatibleOnly = viewModel::toggleOnlyCompatibleWithActiveCar,
                                    onSelectSortMode = viewModel::selectSortMode,
                                    onClearFilters = viewModel::clearAllFilters,
                                    onChangeCarClick = { viewModel.openVehicleSheet() },
                                    onPartClick = { part ->
                                        navController.navigate(AppDestination.partDetailRoute(part.id))
                                    },
                                    onAddToCart = { part -> viewModel.addToCart(part) },
                                    onToggleFavorite = { part -> viewModel.toggleFavorite(part) }
                                )
                            }

                            composable(AppDestination.Garage.route) {
                                GarageScreen(
                                    uiState = uiState,
                                    onAddVehicleClick = { viewModel.openVehicleSheet() },
                                    onActivateVehicle = viewModel::activateExistingVehicle,
                                    onDeleteVehicle = viewModel::deleteVehicle,
                                    onOpenMaintenanceParts = { milestone ->
                                        val primaryCategory = milestone.recommendedCategories.firstOrNull()
                                        if (primaryCategory != null) {
                                            viewModel.applyQuickFilterForCategory(
                                                category = primaryCategory,
                                                compatibleOnly = uiState.activeVehicle != null
                                            )
                                        }
                                        navigateTopLevel(AppDestination.Catalog.route)
                                    },
                                    onBrowseBrand = { brandId ->
                                        viewModel.clearAllFilters()
                                        viewModel.selectBrandFilter(brandId)
                                        navigateTopLevel(AppDestination.Catalog.route)
                                    }
                                )
                            }

                            composable(AppDestination.Cart.route) {
                                CartScreen(
                                    uiState = uiState,
                                    onUpdateQuantity = viewModel::updateCartQuantity,
                                    onRemoveFromCart = viewModel::removeFromCart,
                                    onSelectGovernorate = viewModel::selectGovernorate,
                                    onPlaceOrder = viewModel::placeOrder,
                                    onBrowseCatalog = { navigateTopLevel(AppDestination.Catalog.route) },
                                    onPartClick = { part ->
                                        navController.navigate(AppDestination.partDetailRoute(part.id))
                                    },
                                    onAddToCart = { part -> viewModel.addToCart(part) },
                                    onToggleFavorite = { part -> viewModel.toggleFavorite(part) }
                                )
                            }

                            composable(
                                route = AppDestination.ROUTE_PART_DETAIL,
                                arguments = listOf(navArgument("partId") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val partId = backStackEntry.arguments?.getString("partId") ?: ""
                                val part by viewModel.observePartById(partId).collectAsStateWithLifecycle(initialValue = null)
                                val resolvedPart = part ?: uiState.allParts.find { it.id == partId }

                                if (resolvedPart != null) {
                                    PartDetailScreen(
                                        part = resolvedPart,
                                        compatibleModels = viewModel.compatibleModelsForPart(resolvedPart),
                                        isCompatibleWithActiveCar = resolvedPart.isCompatibleWith(uiState.activeVehicle?.carModelId),
                                        isFavorite = resolvedPart.id in uiState.favoriteIds,
                                        onBack = { navController.popBackStack() },
                                        onAddToCart = { qty -> viewModel.addToCart(resolvedPart, qty) },
                                        onToggleFavorite = { viewModel.toggleFavorite(resolvedPart) },
                                        onCopyOem = { oem ->
                                            viewModel.emitMessage("تم نسخ رقم القطعة: $oem")
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (isVehicleSheetVisible) {
                VehicleSelectorBottomSheet(
                    brands = uiState.brands,
                    modelsForBrandProvider = viewModel::modelsForBrand,
                    onDismiss = { viewModel.closeVehicleSheet() },
                    onConfirmVehicle = viewModel::addAndActivateVehicle
                )
            }
        }
    }
}
