package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SparePartsCatalogSeed
import com.example.data.model.PartCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches localized Arabic title`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("اسبير مصر", appName)
    }

    @Test
    fun `catalog covers all 10 spare part categories and popular Egyptian cars`() {
        val parts = SparePartsCatalogSeed.spareParts
        val models = SparePartsCatalogSeed.carModels

        // Every category has at least 2 parts
        PartCategory.entries.forEach { category ->
            val count = parts.count { it.categoryId == category.id }
            assertTrue("Category ${category.id} should have parts", count >= 2)
        }

        // Popular Egyptian cars exist and have compatible parts
        val popularIds = listOf(
            "nissan_sunny_n17",
            "hyundai_elantra_ad",
            "toyota_corolla_e210",
            "chevy_lanos",
            "byd_f3",
            "mg_5",
            "chery_arrizo5",
            "renault_logan"
        )
        popularIds.forEach { carId ->
            assertTrue("Missing popular Egyptian car $carId", models.any { it.id == carId })
            assertTrue(
                "No compatible parts for $carId",
                parts.any { it.isCompatibleWith(carId) }
            )
        }
    }
}
