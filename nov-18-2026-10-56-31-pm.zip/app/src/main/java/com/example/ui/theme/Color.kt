package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cairo Precision Garage — Light Palette
val SignalCopper = Color(0xFFE85D04)
val SignalCopperDark = Color(0xFFC2410C)
val CopperContainer = Color(0xFFFFEDE3)
val OnCopperContainer = Color(0xFF4A1900)

val DeepAsphalt = Color(0xFF121821)
val AsphaltSlate = Color(0xFF2B3544)
val SlateContainer = Color(0xFFE3E8EF)
val OnSlateContainer = Color(0xFF182230)

val NileTeal = Color(0xFF0F766E)
val TealContainer = Color(0xFFCCFBF1)
val OnTealContainer = Color(0xFF042F2E)

val WorkshopBackground = Color(0xFFF5F6F8)
val PureSurface = Color(0xFFFFFFFF)
val SurfaceMuted = Color(0xFFECEFF3)
val OutlineStone = Color(0xFFD0D7E2)
val TextPrimaryLight = Color(0xFF111827)
val TextSecondaryLight = Color(0xFF4B5563)

// Cairo Precision Garage — Dark Palette
val SignalAmberBright = Color(0xFFFF7B29)
val CopperContainerDark = Color(0xFF5C2200)
val OnCopperContainerDark = Color(0xFFFFD8C2)

val SteelSlateBright = Color(0xFF94A3B8)
val SlateContainerDark = Color(0xFF243040)
val OnSlateContainerDark = Color(0xFFE2E8F0)

val PrecisionTealBright = Color(0xFF2DD4BF)
val TealContainerDark = Color(0xFF11423E)
val OnTealContainerDark = Color(0xFF99F6E4)

val CarbonBackground = Color(0xFF0D1117)
val GraphiteSurface = Color(0xFF161D26)
val GraphiteElevated = Color(0xFF1F2937)
val OutlineCarbon = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

val StatusError = Color(0xFFDC2626)
val StatusErrorDark = Color(0xFFF87171)
val StatusSuccess = Color(0xFF15803D)
val StatusWarning = Color(0xFFD97706)
