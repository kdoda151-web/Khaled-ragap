package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.navigation.SpareMisrApp
import com.example.ui.theme.SpareMisrTheme
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SpareMisrTheme {
                val mainViewModel: MainViewModel = viewModel()
                SpareMisrApp(viewModel = mainViewModel)
            }
        }
    }
}
