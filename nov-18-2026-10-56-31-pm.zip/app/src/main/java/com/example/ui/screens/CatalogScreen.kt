package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PartCategory
import com.example.data.model.PartQuality
import com.example.data.model.SparePartEntity
import com.example.ui.components.ActiveVehicleHeaderBar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SparePartCard
import com.example.ui.viewmodel.CatalogSortMode
import com.example.ui.viewmodel.SpareMisrUiState

@Composable
fun CatalogScreen(
    uiState: SpareMisrUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectCategory: (PartCategory?) -> Unit,
    onSelectQuality: (PartQuality?) -> Unit,
    onSelectBrand: (String?) -> Unit,
    onToggleCompatibleOnly: () -> Unit,
    onSelectSortMode: (CatalogSortMode) -> Unit,
    onClearFilters: () -> Unit,
    onChangeCarClick: () -> Unit,
    onPartClick: (SparePartEntity) -> Unit,
    onAddToCart: (SparePartEntity) -> Unit,
    onToggleFavorite: (SparePartEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val filter = uiState.filterState
    val activeCarId = uiState.activeVehicle?.carModelId
    var sortMenuExpanded by remember { mutableStateOf(false) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .testTag("catalog_screen")
    ) {
        val isWideScreen = maxWidth >= 680.dp

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ActiveVehicleHeaderBar(
                    activeVehicle = uiState.activeVehicle,
                    onChangeCarClick = onChangeCarClick
                )
            }

            // Search Input
            item {
                OutlinedTextField(
                    value = filter.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text("ابحث بالاسم، رقم القطعة OEM، أو الموديل...")
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (filter.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح البحث"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("catalog_search_input")
                )
            }

            // Compatibility + Sort Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = filter.onlyCompatibleWithActiveCar,
                        onClick = {
                            if (uiState.activeVehicle == null) {
                                onChangeCarClick()
                            } else {
                                onToggleCompatibleOnly()
                            }
                        },
                        label = {
                            Text(
                                text = if (uiState.activeVehicle != null) {
                                    "متوافق مع ${uiState.activeVehicle.modelNameAr} فقط"
                                } else {
                                    "حدد سيارتك للفلترة"
                                },
                                maxLines = 1
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (filter.onlyCompatibleWithActiveCar) {
                                    Icons.Default.Check
                                } else {
                                    Icons.Default.DirectionsCar
                                },
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onTertiaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.tertiary
                        ),
                        modifier = Modifier.testTag("compatible_only_chip")
                    )

                    Box {
                        OutlinedButton(
                            onClick = { sortMenuExpanded = true },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Sort,
                                contentDescription = "ترتيب",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = filter.sortMode.titleAr,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        DropdownMenu(
                            expanded = sortMenuExpanded,
                            onDismissRequest = { sortMenuExpanded = false }
                        ) {
                            CatalogSortMode.entries.forEach { mode ->
                                DropdownMenuItem(
                                    text = { Text(mode.titleAr) },
                                    onClick = {
                                        onSelectSortMode(mode)
                                        sortMenuExpanded = false
                                    },
                                    trailingIcon = {
                                        if (filter.sortMode == mode) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Categories Filter Strip
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = filter.selectedCategory == null,
                                onClick = { onSelectCategory(null) },
                                label = { Text("كل الأقسام") }
                            )
                        }
                        items(PartCategory.entries, key = { it.id }) { cat ->
                            FilterChip(
                                selected = filter.selectedCategory == cat,
                                onClick = {
                                    onSelectCategory(if (filter.selectedCategory == cat) null else cat)
                                },
                                label = { Text(cat.titleAr) }
                            )
                        }
                    }

                    // Egyptian Car Brands Filter Strip
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = filter.selectedBrandId == null,
                                onClick = { onSelectBrand(null) },
                                label = { Text("كل الماركات") }
                            )
                        }
                        items(uiState.brands, key = { it.id }) { brand ->
                            FilterChip(
                                selected = filter.selectedBrandId == brand.id,
                                onClick = {
                                    onSelectBrand(if (filter.selectedBrandId == brand.id) null else brand.id)
                                },
                                label = { Text(brand.nameAr) }
                            )
                        }
                    }

                    // Part Quality / Origin Filter Strip
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = filter.selectedQuality == null,
                                onClick = { onSelectQuality(null) },
                                label = { Text("كل الفئات (أصلي/بديل)") }
                            )
                        }
                        items(PartQuality.entries, key = { it.id }) { q ->
                            FilterChip(
                                selected = filter.selectedQuality == q,
                                onClick = {
                                    onSelectQuality(if (filter.selectedQuality == q) null else q)
                                },
                                label = { Text(q.titleAr) }
                            )
                        }
                    }
                }
            }

            // Results Count Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "النتائج المتاحة (${uiState.filteredParts.size} قطعة)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (filter.selectedCategory != null ||
                        filter.selectedQuality != null ||
                        filter.selectedBrandId != null ||
                        filter.searchQuery.isNotEmpty() ||
                        filter.onlyCompatibleWithActiveCar
                    ) {
                        Text(
                            text = "مسح الكل",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clickable { onClearFilters() }
                                .padding(4.dp)
                                .testTag("clear_filters_btn")
                        )
                    }
                }
            }

            // Results List or 2-Column Grid
            if (uiState.filteredParts.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.SearchOff,
                        title = "لا توجد قطع غيار مطابقة",
                        subtitle = "جرب إزالة بعض الفلاتر أو البحث بكلمة أعم مثل (تيل، فلتر، مساعد، بوجيهات).",
                        actionLabel = "إعادة ضبط الفلاتر",
                        onActionClick = onClearFilters
                    )
                }
            } else if (isWideScreen) {
                val rows = uiState.filteredParts.chunked(2)
                items(rows) { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { part ->
                            Box(modifier = Modifier.weight(1f)) {
                                SparePartCard(
                                    part = part,
                                    isCompatibleWithActiveCar = part.isCompatibleWith(activeCarId),
                                    isFavorite = part.id in uiState.favoriteIds,
                                    onCardClick = { onPartClick(part) },
                                    onAddToCart = { onAddToCart(part) },
                                    onToggleFavorite = { onToggleFavorite(part) }
                                )
                            }
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            } else {
                items(uiState.filteredParts, key = { it.id }) { part ->
                    SparePartCard(
                        part = part,
                        isCompatibleWithActiveCar = part.isCompatibleWith(activeCarId),
                        isFavorite = part.id in uiState.favoriteIds,
                        onCardClick = { onPartClick(part) },
                        onAddToCart = { onAddToCart(part) },
                        onToggleFavorite = { onToggleFavorite(part) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
