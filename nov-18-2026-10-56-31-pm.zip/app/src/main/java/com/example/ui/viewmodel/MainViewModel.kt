package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SpareMisrDatabase
import com.example.data.model.CartItemWithPart
import com.example.data.model.EgyptGovernorate
import com.example.data.model.EgyptianCarBrand
import com.example.data.model.EgyptianCarModel
import com.example.data.model.GarageVehicleEntity
import com.example.data.model.MaintenanceMilestone
import com.example.data.model.OrderEntity
import com.example.data.model.PartCategory
import com.example.data.model.PartQuality
import com.example.data.model.SparePartEntity
import com.example.data.repository.SparePartsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CatalogSortMode(val titleAr: String) {
    COMPATIBILITY_FIRST("الأنسب لسيارتي"),
    TOP_RATED("الأعلى تقييماً"),
    PRICE_LOW_HIGH("الأقل سعراً"),
    PRICE_HIGH_LOW("الأعلى سعراً")
}

data class CatalogFilterState(
    val searchQuery: String = "",
    val selectedCategory: PartCategory? = null,
    val selectedQuality: PartQuality? = null,
    val onlyCompatibleWithActiveCar: Boolean = false,
    val selectedBrandId: String? = null,
    val sortMode: CatalogSortMode = CatalogSortMode.COMPATIBILITY_FIRST
)

data class SpareMisrUiState(
    val isLoading: Boolean = true,
    val allParts: List<SparePartEntity> = emptyList(),
    val filteredParts: List<SparePartEntity> = emptyList(),
    val popularParts: List<SparePartEntity> = emptyList(),
    val filterState: CatalogFilterState = CatalogFilterState(),
    val garageVehicles: List<GarageVehicleEntity> = emptyList(),
    val activeVehicle: GarageVehicleEntity? = null,
    val cartItems: List<CartItemWithPart> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val orders: List<OrderEntity> = emptyList(),
    val selectedGovernorate: EgyptGovernorate,
    val brands: List<EgyptianCarBrand> = emptyList(),
    val allCarModels: List<EgyptianCarModel> = emptyList(),
    val topEgyptianCars: List<EgyptianCarModel> = emptyList(),
    val governorates: List<EgyptGovernorate> = emptyList(),
    val maintenanceMilestones: List<MaintenanceMilestone> = emptyList()
) {
    val cartTotalCount: Int
        get() = cartItems.sumOf { it.cartItem.quantity }

    val cartSubtotalEgp: Int
        get() = cartItems.sumOf { it.part.priceEgp * it.cartItem.quantity }

    val cartGrandTotalEgp: Int
        get() = if (cartItems.isEmpty()) 0 else cartSubtotalEgp + selectedGovernorate.shippingFeeEgp

    val favoriteParts: List<SparePartEntity>
        get() = allParts.filter { it.id in favoriteIds }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SparePartsRepository = SparePartsRepository(
        SpareMisrDatabase.getInstance(application).sparePartsDao()
    )

    private val _filterState = MutableStateFlow(CatalogFilterState())
    private val _selectedGovernorate = MutableStateFlow(repository.governorates.first())
    private val _isVehicleSheetVisible = MutableStateFlow(false)
    val isVehicleSheetVisible: StateFlow<Boolean> = _isVehicleSheetVisible.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    private val catalogInputsFlow = combine(
        repository.allParts,
        _filterState,
        repository.activeVehicle,
        repository.garageVehicles
    ) { parts, filter, activeCar, garage ->
        CatalogBundle(parts, filter, activeCar, garage)
    }

    private val userInputsFlow = combine(
        repository.cartItemsWithParts,
        repository.favoriteIds,
        repository.orders,
        _selectedGovernorate
    ) { cart, favs, orders, gov ->
        UserBundle(cart, favs.toSet(), orders, gov)
    }

    val uiState: StateFlow<SpareMisrUiState> = combine(
        catalogInputsFlow,
        userInputsFlow
    ) { catalog, user ->
        val filtered = applyFiltersAndSort(
            parts = catalog.parts,
            filter = catalog.filter,
            activeVehicle = catalog.activeVehicle
        )
        val popular = catalog.parts.filter { it.isPopularInEgypt }
        SpareMisrUiState(
            isLoading = false,
            allParts = catalog.parts,
            filteredParts = filtered,
            popularParts = popular,
            filterState = catalog.filter,
            garageVehicles = catalog.garage,
            activeVehicle = catalog.activeVehicle,
            cartItems = user.cart,
            favoriteIds = user.favIds,
            orders = user.orders,
            selectedGovernorate = user.governorate,
            brands = repository.brands,
            allCarModels = repository.allCarModels,
            topEgyptianCars = repository.allCarModels.filter { it.isTopSellerInEgypt },
            governorates = repository.governorates,
            maintenanceMilestones = repository.maintenanceMilestones
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SpareMisrUiState(
            selectedGovernorate = repository.governorates.first(),
            brands = repository.brands,
            allCarModels = repository.allCarModels,
            topEgyptianCars = repository.allCarModels.filter { it.isTopSellerInEgypt },
            governorates = repository.governorates,
            maintenanceMilestones = repository.maintenanceMilestones
        )
    )

    init {
        viewModelScope.launch {
            repository.initializeDatabase()
        }
    }

    fun observePartById(partId: String): Flow<SparePartEntity?> =
        repository.observePartById(partId)

    fun compatibleModelsForPart(part: SparePartEntity): List<EgyptianCarModel> =
        repository.compatibleModelsForPart(part)

    fun modelsForBrand(brandId: String): List<EgyptianCarModel> =
        repository.modelsForBrand(brandId)

    fun openVehicleSheet() {
        _isVehicleSheetVisible.value = true
    }

    fun closeVehicleSheet() {
        _isVehicleSheetVisible.value = false
    }

    fun updateSearchQuery(query: String) {
        _filterState.update { it.copy(searchQuery = query) }
    }

    fun selectCategory(category: PartCategory?) {
        _filterState.update { it.copy(selectedCategory = category) }
    }

    fun selectQuality(quality: PartQuality?) {
        _filterState.update { it.copy(selectedQuality = quality) }
    }

    fun toggleOnlyCompatibleWithActiveCar() {
        _filterState.update {
            it.copy(onlyCompatibleWithActiveCar = !it.onlyCompatibleWithActiveCar)
        }
    }

    fun setOnlyCompatibleWithActiveCar(enabled: Boolean) {
        _filterState.update { it.copy(onlyCompatibleWithActiveCar = enabled) }
    }

    fun selectBrandFilter(brandId: String?) {
        _filterState.update { it.copy(selectedBrandId = brandId) }
    }

    fun selectSortMode(mode: CatalogSortMode) {
        _filterState.update { it.copy(sortMode = mode) }
    }

    fun clearAllFilters() {
        _filterState.value = CatalogFilterState()
    }

    fun applyQuickFilterForCategory(category: PartCategory, compatibleOnly: Boolean = false) {
        _filterState.update {
            it.copy(
                selectedCategory = category,
                onlyCompatibleWithActiveCar = compatibleOnly,
                searchQuery = ""
            )
        }
    }

    fun addAndActivateVehicle(
        model: EgyptianCarModel,
        year: Int,
        engineSpec: String,
        nickname: String
    ) {
        viewModelScope.launch {
            repository.addAndActivateVehicle(model, year, engineSpec, nickname)
            _isVehicleSheetVisible.value = false
            _snackbarMessages.emit("تم اختيار ${model.displayTitleAr} ($year) كسيارتك النشطة")
        }
    }

    fun quickActivatePopularCar(model: EgyptianCarModel) {
        viewModelScope.launch {
            repository.addAndActivateVehicle(
                model = model,
                year = model.yearTo.coerceAtMost(2024),
                engineSpec = model.engineSpecs.firstOrNull() ?: "قياسي",
                nickname = model.displayTitleAr
            )
            _filterState.update { it.copy(onlyCompatibleWithActiveCar = true) }
            _snackbarMessages.emit("يتم الآن عرض القطع المتوافقة مع ${model.displayTitleAr}")
        }
    }

    fun activateExistingVehicle(vehicle: GarageVehicleEntity) {
        viewModelScope.launch {
            repository.activateVehicle(vehicle.id)
            _snackbarMessages.emit("تم التبديل إلى ${vehicle.brandNameAr} ${vehicle.modelNameAr}")
        }
    }

    fun deleteVehicle(vehicle: GarageVehicleEntity) {
        viewModelScope.launch {
            repository.deleteVehicle(vehicle.id)
            _snackbarMessages.emit("تم حذف السيارة من الجراج")
        }
    }

    fun addToCart(part: SparePartEntity, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToCart(part.id, quantity)
            _snackbarMessages.emit("تمت إضافة ${part.nameAr} إلى السلة")
        }
    }

    fun updateCartQuantity(partId: String, quantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(partId, quantity)
        }
    }

    fun removeFromCart(partId: String) {
        viewModelScope.launch {
            repository.removeFromCart(partId)
            _snackbarMessages.emit("تمت إزالة القطعة من السلة")
        }
    }

    fun toggleFavorite(part: SparePartEntity) {
        viewModelScope.launch {
            val isCurrentlyFav = part.id in uiState.value.favoriteIds
            repository.toggleFavorite(part.id)
            _snackbarMessages.emit(
                if (isCurrentlyFav) "تمت الإزالة من المفضلة" else "تم الحفظ في المفضلة"
            )
        }
    }

    fun selectGovernorate(governorate: EgyptGovernorate) {
        _selectedGovernorate.value = governorate
    }

    fun placeOrder(
        customerName: String,
        phone: String,
        address: String,
        paymentMethodAr: String,
        onSuccess: (OrderEntity) -> Unit
    ) {
        val currentState = uiState.value
        if (currentState.cartItems.isEmpty()) return
        viewModelScope.launch {
            val order = repository.placeOrder(
                customerName = customerName,
                phone = phone,
                governorate = currentState.selectedGovernorate,
                address = address,
                paymentMethodAr = paymentMethodAr,
                cartItems = currentState.cartItems
            )
            _snackbarMessages.emit("تم تأكيد طلبك رقم ${order.orderNumber} بنجاح")
            onSuccess(order)
        }
    }

    fun emitMessage(message: String) {
        viewModelScope.launch {
            _snackbarMessages.emit(message)
        }
    }

    private fun applyFiltersAndSort(
        parts: List<SparePartEntity>,
        filter: CatalogFilterState,
        activeVehicle: GarageVehicleEntity?
    ): List<SparePartEntity> {
        val query = filter.searchQuery.trim().lowercase()
        val activeCarId = activeVehicle?.carModelId

        val brandCarIds = filter.selectedBrandId?.let { brandId ->
            repository.modelsForBrand(brandId).map { it.id }.toSet()
        }

        val filtered = parts.filter { part ->
            val matchesQuery = if (query.isEmpty()) {
                true
            } else {
                part.nameAr.lowercase().contains(query) ||
                    part.nameEn.lowercase().contains(query) ||
                    part.oemNumber.lowercase().contains(query) ||
                    part.subCategoryAr.lowercase().contains(query) ||
                    part.brandMaker.lowercase().contains(query) ||
                    part.descriptionAr.lowercase().contains(query) ||
                    repository.compatibleModelsForPart(part).any { car ->
                        car.nameAr.lowercase().contains(query) ||
                            car.brandNameAr.lowercase().contains(query) ||
                            car.nameEn.lowercase().contains(query)
                    }
            }

            val matchesCategory = filter.selectedCategory == null ||
                part.categoryId == filter.selectedCategory.id

            val matchesQuality = filter.selectedQuality == null ||
                part.qualityId == filter.selectedQuality.id

            val matchesActiveCar = !filter.onlyCompatibleWithActiveCar ||
                part.isCompatibleWith(activeCarId)

            val matchesBrand = brandCarIds == null ||
                part.compatibleCarIdsCsv.contains("ALL_EGYPT") ||
                part.compatibleCarIdsCsv.split(",").any { it.trim() in brandCarIds }

            matchesQuery && matchesCategory && matchesQuality && matchesActiveCar && matchesBrand
        }

        return when (filter.sortMode) {
            CatalogSortMode.COMPATIBILITY_FIRST -> {
                filtered.sortedWith(
                    compareByDescending<SparePartEntity> { it.isCompatibleWith(activeCarId) }
                        .thenByDescending { it.isPopularInEgypt }
                        .thenByDescending { it.rating }
                )
            }
            CatalogSortMode.TOP_RATED -> filtered.sortedByDescending { it.rating }
            CatalogSortMode.PRICE_LOW_HIGH -> filtered.sortedBy { it.priceEgp }
            CatalogSortMode.PRICE_HIGH_LOW -> filtered.sortedByDescending { it.priceEgp }
        }
    }

    private data class CatalogBundle(
        val parts: List<SparePartEntity>,
        val filter: CatalogFilterState,
        val activeVehicle: GarageVehicleEntity?,
        val garage: List<GarageVehicleEntity>
    )

    private data class UserBundle(
        val cart: List<CartItemWithPart>,
        val favIds: Set<String>,
        val orders: List<OrderEntity>,
        val governorate: EgyptGovernorate
    )
}
