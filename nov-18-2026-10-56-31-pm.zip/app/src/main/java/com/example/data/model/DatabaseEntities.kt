package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "spare_parts")
data class SparePartEntity(
    @PrimaryKey val id: String,
    val nameAr: String,
    val nameEn: String,
    val oemNumber: String,
    val categoryId: String,
    val subCategoryAr: String,
    val brandMaker: String,
    val originCountryAr: String,
    val qualityId: String,
    val priceEgp: Int,
    val oldPriceEgp: Int?,
    val inStock: Boolean,
    val stockCount: Int,
    val warrantyMonths: Int,
    val positionAr: String,
    val descriptionAr: String,
    val buyerTipAr: String,
    val compatibleCarIdsCsv: String,
    val compatibleYearsLabel: String,
    val isPopularInEgypt: Boolean,
    val rating: Float
) {
    fun isCompatibleWith(carModelId: String?): Boolean {
        if (carModelId.isNullOrBlank()) return false
        if (compatibleCarIdsCsv.contains("ALL_EGYPT")) return true
        return compatibleCarIdsCsv.split(",").any { it.trim() == carModelId }
    }
}

@Entity(tableName = "garage_vehicles")
data class GarageVehicleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val carModelId: String,
    val brandNameAr: String,
    val modelNameAr: String,
    val chassisCode: String,
    val year: Int,
    val engineSpec: String,
    val nickname: String,
    val isActive: Boolean,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val partId: String,
    val quantity: Int,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_parts")
data class FavoritePartEntity(
    @PrimaryKey val partId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderNumber: String,
    val customerName: String,
    val phone: String,
    val governorateAr: String,
    val address: String,
    val paymentMethodAr: String,
    val totalEgp: Int,
    val shippingEgp: Int,
    val itemsSummaryAr: String,
    val itemCount: Int,
    val statusAr: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class CartItemWithPart(
    val cartItem: CartItemEntity,
    val part: SparePartEntity
)
