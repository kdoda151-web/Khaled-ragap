package com.example.data.model

enum class PartCategory(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val titleEn: String
) {
    ENGINE(
        id = "engine",
        titleAr = "المحرك ومكوناته",
        subtitleAr = "بساتم، كاتينة، بوجيهات، كراسي موتور",
        titleEn = "Engine & Timing"
    ),
    FILTERS_OILS(
        id = "filters_oils",
        titleAr = "الفلاتر والزيوت",
        subtitleAr = "فلاتر زيت وهواء وتكييف وزيوت تخليقية",
        titleEn = "Filters & Oils"
    ),
    BRAKES(
        id = "brakes",
        titleAr = "نظام الفرامل",
        subtitleAr = "تيل سيراميك، طنابير، ماستر، ABS",
        titleEn = "Braking System"
    ),
    SUSPENSION(
        id = "suspension",
        titleAr = "العفشة والتوجيه",
        subtitleAr = "مساعدين، مقصات، كبالن، علبة دركسيون",
        titleEn = "Suspension & Steering"
    ),
    TRANSMISSION(
        id = "transmission",
        titleAr = "الفتيس والدبرياج",
        subtitleAr = "طقم دبرياج، فلاتر CVT/AT، كراسي فتيس",
        titleEn = "Transmission"
    ),
    ELECTRICAL(
        id = "electrical",
        titleAr = "الكهرباء والحساسات",
        subtitleAr = "دينامو، مارش، بطاريات، حساسات، مباين",
        titleEn = "Electrical & Sensors"
    ),
    COOLING_AC(
        id = "cooling_ac",
        titleAr = "التبريد والتكييف",
        subtitleAr = "رداتير، طرمبة مياه، كمبروسور، كوندنسر",
        titleEn = "Cooling & A/C"
    ),
    LIGHTING_GLASS(
        id = "lighting_glass",
        titleAr = "الإضاءة والمرايات",
        subtitleAr = "فوانيس، شبورة، مرايات ضم، مساحات",
        titleEn = "Lighting & Mirrors"
    ),
    BODY_EXTERIOR(
        id = "body_exterior",
        titleAr = "البودي والهيكل",
        subtitleAr = "اكصدامات، مصفحة، شبكات، كوالين",
        titleEn = "Body & Exterior"
    ),
    EXHAUST_FUEL(
        id = "exhaust_fuel",
        titleAr = "العادم والوقود",
        subtitleAr = "طرمبة بنزين، رشاشات، بوابة، علبة بيئة",
        titleEn = "Exhaust & Fuel"
    );

    companion object {
        fun fromId(id: String): PartCategory? = entries.find { it.id == id }
    }
}

enum class PartQuality(
    val id: String,
    val titleAr: String,
    val badgeAr: String
) {
    OEM_GENUINE("oem", "أصلي وكالة (OEM)", "أصلي وكالة"),
    EUROPEAN_JAPANESE("eu_jp", "ألماني / ياباني", "مستورد ممتاز"),
    KOREAN_OEM("korean", "كوري أصلي", "كوري معتمد"),
    TAIWAN_FIRST("taiwan", "تايواني / صيني فرز أول", "فرز أول"),
    IMPORT_USED("import", "استيراد فابريكا", "استيراد")
    ;

    companion object {
        fun fromId(id: String): PartQuality? = entries.find { it.id == id }
    }
}

data class EgyptianCarBrand(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val countryAr: String,
    val marketShareNote: String
)

data class EgyptianCarModel(
    val id: String,
    val brandId: String,
    val brandNameAr: String,
    val nameAr: String,
    val nameEn: String,
    val chassisCode: String,
    val yearFrom: Int,
    val yearTo: Int,
    val engineSpecs: List<String>,
    val isTopSellerInEgypt: Boolean = false
) {
    val displayTitleAr: String
        get() = "$brandNameAr $nameAr"

    val yearsRangeText: String
        get() = "$yearFrom - $yearTo"
}

data class EgyptGovernorate(
    val id: String,
    val nameAr: String,
    val shippingFeeEgp: Int,
    val deliveryEtaAr: String
)

data class MaintenanceMilestone(
    val kmInterval: Int,
    val titleAr: String,
    val descriptionAr: String,
    val recommendedCategories: List<PartCategory>,
    val searchKeywords: List<String>
)
